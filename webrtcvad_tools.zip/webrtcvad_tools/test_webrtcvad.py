import collections
import contextlib
import sys
import wave
import os
import webrtcvad
from tqdm import tqdm
import argparse
from vad_collector import get_vad_result


MODE = 3
SKIP_SHORT_ONES = 5    # 單位 frame
MAX_CLIP_LENGTH = 500  # (單位 frame *30) /1000後就是要收集的秒數

class Frame(object):
    """Represents a "frame" of audio data."""
    def __init__(self, bytes, timestamp, duration):
        self.bytes = bytes
        self.timestamp = timestamp
        self.duration = duration

class Webrtcvad_tools:
    def __init_(self):
        pass
    def read_wave(self, path):
        """Reads a .wav file.
        Takes the path, and returns (PCM audio data, sample rate).
        """
        with contextlib.closing(wave.open(path, 'rb')) as wf:
            num_channels = wf.getnchannels()
            assert num_channels == 1
            sample_width = wf.getsampwidth()
            assert sample_width == 2
            sample_rate = wf.getframerate()
            assert sample_rate in (8000, 16000, 32000, 48000)
            pcm_data = wf.readframes(wf.getnframes())
            return pcm_data, sample_rate
    def write_wave(self, path, audio, sample_rate):
        """Writes a .wav file.
        Takes path, PCM audio data, and sample rate.
        """
        with contextlib.closing(wave.open(path, 'wb')) as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(audio)

    def frame_generator(self, frame_duration_ms, audio, sample_rate):
        """Generates audio frames from PCM audio data.
        Takes the desired frame duration in milliseconds, the PCM data, and
        the sample rate.
        Yields Frames of the requested duration.
        """
        n = int(sample_rate * (frame_duration_ms / 1000.0) * 2)
        offset = 0
        timestamp = 0.0
        duration = (float(n) / sample_rate) / 2.0
        while offset + n < len(audio):
            yield Frame(audio[offset:offset + n], timestamp, duration)
            timestamp += duration
            offset += n

    def vad_collector(self, sample_rate, vad, frame):

        voiced_frames = []
        is_speech = vad.is_speech(frame.bytes, sample_rate)
        print(is_speech)
        input()
        if is_speech:
            voiced_frames.append(frame)
            return b''.join(f.bytes for f in voiced_frames)
        else:
            pass

    def get_vad_list(self, sample_rate, vad, frames):
        voiced_frames = []
        for i in frames:
            is_speech = vad.is_speech(i.bytes, sample_rate)
            if is_speech:
                voiced_frames.append(1)
            else:
                voiced_frames.append(0)
        return voiced_frames

    def voiced_frames_expand(self, voiced_frames, duration=6):
        total = duration * 16000
        expand_voiced_frames = voiced_frames
        while len(expand_voiced_frames) < total:
            expand_num = total - len(expand_voiced_frames)
            expand_voiced_frames += voiced_frames[: expand_num]
        return expand_voiced_frames


    def store_frame_2_wav(self, frames, sample_rate, out_dir: str, wavpath: str, start: int, end: int):
        wav_name = os.path.basename(wavpath)
        wav_name = wav_name.split('.')[0]
        save_path = f'{out_dir}/{wav_name}_{start:06}_{end:06}.wav'
        self.write_wave(save_path, frames, sample_rate)


def filter(wavpath, out_dir, expand=False):
    os.makedirs(out_dir, exist_ok=True)
    tw = Webrtcvad_tools()
    audio, sample_rate = tw.read_wave(wavpath)
    vad = webrtcvad.Vad(MODE)
    frames = tw.frame_generator(30, audio, sample_rate)
    frames = list(frames)

    vad_info = tw.get_vad_list(sample_rate, vad, frames)
    vad_interval = get_vad_result(vad_info, SKIP_SHORT_ONES, MAX_CLIP_LENGTH)
    print(vad_interval[:10])
    for start, end in tqdm(vad_interval):
        voiced_frame_total = []
        for i in range(start, end+1):
            voiced_frame_total.append(frames[i].bytes)
        voiced_frames = b''.join(f for f in voiced_frame_total)
        tw.store_frame_2_wav(voiced_frames, sample_rate, out_dir, wavpath, start, end)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('in_wav', help='wav file')
    parser.add_argument('output_path', help='output wav path')
    args = parser.parse_args()
    in_wave = args.in_wav
    outwav = args.output_path
    os.makedirs(outwav, exist_ok=True)
    filter(in_wave, outwav, expand=False)
