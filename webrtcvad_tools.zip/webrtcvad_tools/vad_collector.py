import numpy as np
from typing import List


def find_consecutive_ones(input_list):
    result = []
    start = None
    for i in range(len(input_list)):
        if input_list[i] == 1 and start is None:
            # 開始新的連續 1 範圍
            start = i
        elif input_list[i] == 0 and start is not None:
            # 結束連續 1 範圍
            result.append((start, i - 1))
            start = None
    if start is not None:
        # 處理列表結尾的連續 1
        result.append((start, len(input_list) - 1))
    return result


def filter_out_short_ones(input_list: list, min_length: int):
    # 處理掉過短的連續 1 的區間
    res = []
    for i in input_list:
        if i[1] - i[0] + 1 >= min_length:
            res.append(i)
    return res


def combine_multi_interval(input_list: list, max_l):
    # 對於連續區間，如果合併後長度小於 max_l，就合併多個連續區間
    res = []
    i = 0
    j = 0
    while i < len(input_list) and j < len(input_list):
        ij_len = input_list[j][1] - input_list[i][0] + 1
        if ij_len >= max_l and i == j:
            res.append((input_list[i][0], input_list[j][1]))
            i = j = j + 1
        elif ij_len >= max_l:
            res.append((input_list[i][0], input_list[j-1][1]))
            i = j
        else:
            j += 1
        # 處理最後一個
        if j == len(input_list) and i <= j and ij_len < max_l:
            res.append((input_list[i][0], input_list[j-1][1]))
    return res


def get_vad_result(input_list: List[int], min_conti_ones: int, max_len: int):
    x = find_consecutive_ones(input_list)
    # x = filter_out_short_ones(x, min_conti_ones)
    x = combine_multi_interval(x, max_len)
    return x


if __name__ == '__main__':
    i = [0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0,
         1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1]
    x = find_consecutive_ones(i)
    print(x)
    y = filter_out_short_ones(x, 3)
    print(y)
    z = combine_multi_interval(y, 15)
    print(z)
